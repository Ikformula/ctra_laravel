@for($y = 1; $y <= 31; $y++)
    <option value="{{ $y }}">{{ $y }}</option>
@endfor
